Spanish Study/
	__init__.py
	__main__.py
	python files/
		__init__.py
		easygui.py
		guiController.py
		listChecker.py
		logicClass.py
		menuCommands.py
		startup.py
		TkinterGUI.py